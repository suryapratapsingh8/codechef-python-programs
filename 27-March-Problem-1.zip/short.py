n=int(input())
l=list(map(int,input().split()))
k=[]
for i in range(n):
    c=0
    for j in range(n):
        if l[i]>l[j]:
          c=c+1
    k.append(c)
    c=0
res=str(k)[1:-1]
res.replace(",","")
print(res)