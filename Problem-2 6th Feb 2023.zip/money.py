n=int(input())
k=int(input())

s=0
for i in range(1,n+1):
    s=s%(10**9+7)
    if s+i!=k:
        s=s+i

print(s%((10**9)+7))
    
    