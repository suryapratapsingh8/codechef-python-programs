n=int(input())
k=int(input())
l=[]
for i in range(k):
    m=int(input())
    for j in range(m,n+1,m):
        l.append(j)
p=set(l)
print(n-len(p))
        