l=list(map(int,input().split()))
n=int(input())
ind=0
la=0
f=0
for i in range(len(l)):
    if l[i]==n:
        ind=i+1
        f=1 
    elif l[i]==n and f==1:
        la=i+1 
if ind==0:
    print('-1 -1')
elif ind>0 and la==0:
    print(ind-1,-1)
else:
    print(ind-1,la-1)

        