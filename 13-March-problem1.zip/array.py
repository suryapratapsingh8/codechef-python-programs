l=list(map(int,input().split()))
l.sort()
m=0 
f=0 
r=0
for i in range(1,len(l)):
    if l[i]-l[i-1]!=1 and f==0:
        m=l[i]-1 
        f=1
    elif l[i]-l[i-1]==0:
        r=l[i]
print(r,m)
        
    