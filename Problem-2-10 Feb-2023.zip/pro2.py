def main():
    number=int(input())
    counter1=0
    counter2=0
    closestIntegerPalindrome1=number
    closestIntegerPalindrome1=number
    for n in range(number,number-100,-1):
        if isPalindrome(n):
            closestIntegerPalindrome1=n
            break
        counter1+=1
    for n in range(number,number+100):
        if isPalindrome(n):
            closestIntegerPalindrome2=n
            break
        counter2+=1


    if(counter1<counter2):
        print(closestIntegerPalindrome1)
    else:
        print(closestIntegerPalindrome2)


def isPalindrome(number):
    tempNumber=number
    reverseNumber=0
    while(number>0):
        digit=number%10
        reverseNumber=reverseNumber*10+digit
        number=number//10
    if(tempNumber==reverseNumber):
        return True
    else:
        return False

main()