s=input()
n=set()
for i in s:
    if i.isdigit():
        n.add(i)
n=sorted(list(set (n)), reverse=True) 
even= [x for x in n if int(x)%2==0]
if len(even)==0:
    print(-1)

else:
    if int(n[-1])%2==0:
        print("".join(n))
    else:
        n.remove(even [-1])
        n.append(even [-1])
        print("".join(n))