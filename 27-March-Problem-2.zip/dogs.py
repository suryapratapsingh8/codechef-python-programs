n,i,j,m,p=map(int,input().split())
y=m//i+p//j
print(n-y)