s,b=map(int,input().split())
t=0 
for i in range(s):
    t=i+(i+1)
    if t==b:
        t=t-1
print(t)